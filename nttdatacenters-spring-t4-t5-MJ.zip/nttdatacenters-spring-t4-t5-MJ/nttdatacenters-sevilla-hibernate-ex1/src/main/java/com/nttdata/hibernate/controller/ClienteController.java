package com.nttdata.hibernate.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nttdata.hibernate.controller.dto.ClientDTO;
import com.nttdata.hibernate.persistence.Client;
import com.nttdata.hibernate.services.ClientManagementServiceI;

@Controller
@RequestMapping("/cliente")
public class ClienteController {
	
	@Autowired
	private ClientManagementServiceI clientService;
	
	@GetMapping(value = "/")
	public String obtenerClientes(Model model) {
		List<Client> clientes = new ArrayList<>();
		clientes.add(new Client());
		clientes.add(new Client());
		clientes.add(new Client());
		clientes.add(new Client());
		
		model.addAttribute("clientes", clientes);
		return "clientes";
	}
	
	@RequestMapping(value = "/", method = RequestMethod.POST)
	public void guardarCliente(@RequestBody ClientDTO clientDTO, Model model) {
		Client client = new Client();
		client.setDni(clientDTO.getDni());
		client.setName(clientDTO.getName());
		client.setLastName(clientDTO.getLastName());
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public String obtenerCliente(@PathVariable Long id, Model model) {
		Client client = new Client();
		client.setClientId(id);
		model.addAttribute("cliente", client);
		return "cliente";
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void eliminarCliente (@PathVariable Long id, Model model) {
		Client client = new Client();
		client.setClientId(id);
//		clientService.deleteClient(client);
	}
	
	

}
