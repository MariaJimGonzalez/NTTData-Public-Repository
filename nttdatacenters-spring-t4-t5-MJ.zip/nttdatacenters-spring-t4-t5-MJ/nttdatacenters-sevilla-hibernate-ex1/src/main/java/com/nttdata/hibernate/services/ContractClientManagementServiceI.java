package com.nttdata.hibernate.services;

import java.util.List;

import com.nttdata.hibernate.persistence.Client;
import com.nttdata.hibernate.persistence.ContractClient;

public interface ContractClientManagementServiceI {

	/**
	 * Inserta un nuevo contrato.
	 * 
	 * @param newClient
	 */
	public void insertNewContract(final ContractClient newContract);

	/**
	 * Actualiza un contrato existente.
	 * 
	 * @param updatedClient
	 */
	public void updateContract(final ContractClient updatedContract);

	/**
	 * Elimina un contrato existente.
	 * 
	 * @param deletedClient
	 */
	public void deleteContract(final ContractClient deletedContract);

	/**
	 * Obtiene un contrato mediante su ID.
	 * 
	 * @param clientId
	 */
	public ContractClient searchById(final Long contractId);

	List<Client> searchAll();

	/**
	 * Obtiene todos los contratos existentes.
	 * 
	 * @return List<Contract>
	 */


}
