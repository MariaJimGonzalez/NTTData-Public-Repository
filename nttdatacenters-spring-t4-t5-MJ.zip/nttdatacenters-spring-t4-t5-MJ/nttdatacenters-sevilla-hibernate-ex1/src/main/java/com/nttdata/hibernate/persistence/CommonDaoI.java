package com.nttdata.hibernate.persistence;

import java.util.List;


public interface CommonDaoI<T> {
	
	

	/**
	 * Inserta un registro en BBDD.
	 * 
	 * @param newClient
	 */
	public void  insert(final T newClient);

	/**
	 * Actualiza un registro en BBDD.
	 * 
	 * @param updatedClient
	 */
	public void update(final T updatedClient);
	
	/**
	 * Elimina un registro en BBDD.
	 * 
	 * @param deletedClient
	 */
	public void delete(final T deletedClient);
	
	/**
	 * Localiza un registro por ID en BBDD.
	 * 
	 * @param paramT
	 */
	public T searchById(final Long id);

	/**
	 * Búsqueda de todos los registros en BBDD.
	 * 
	 * @return List<T>
	 */
	public List<Client> searchAll();


}
