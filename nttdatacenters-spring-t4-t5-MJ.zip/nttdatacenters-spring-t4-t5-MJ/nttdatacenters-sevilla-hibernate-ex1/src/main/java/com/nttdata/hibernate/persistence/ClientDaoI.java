package com.nttdata.hibernate.persistence;

import java.util.List;

public interface ClientDaoI extends CommonDaoI<Client>{
	

	public List<Client> searchByNameAndLastName(String name, String lastName);

}
