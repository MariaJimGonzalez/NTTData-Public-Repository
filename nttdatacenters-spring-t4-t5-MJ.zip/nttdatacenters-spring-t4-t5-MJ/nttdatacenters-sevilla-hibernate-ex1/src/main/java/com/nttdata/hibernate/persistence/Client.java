package com.nttdata.hibernate.persistence;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Max;


@Entity
@Table(name = "T1H_CLIENT")
public class Client extends AbstractEntity implements  Serializable {

	/** Serial Version */
	private static final long serialVersionUID = 1L;

	/** Identificador (PK) */
	private Long clientId;

	/** Nombre del cliente */
	private String name;

	/** apellido del cliente */
	private String lastName;

	/** dni del cliente */
	private String dni;

	/** lista de contratos */

	private List <ContractClient> contractClient;

	/**
	 * @return the clientId
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CLIENT_ID")
	public Long getClientId() {
		return clientId;
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the last name
	 */
	@Column(name = "LAST_NAME", nullable = false)
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the last name to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	/**
	 * @return the name
	 */
	@Column(name = "NAME", nullable = false)
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the dni
	 */
	@Column(name = "DNI")
	@Max(9)
	public String getDni() {
		return dni;
	}

	/**
	 * @param dni
	 *            the dni to set
	 */
	public void setDni(String dni) {
		this.dni = dni;
	}

	/**
	 * @param contractClient
	 *            a list of the contracts
	 */
	@OneToMany(mappedBy = "client")
	public List<ContractClient> getContractClient() {
		return contractClient;
	}

	public void setContractClient(List<ContractClient> contractClient) {
		this.contractClient = contractClient;
	}


	@Transient
	public Class<?> getClase() {
		return Client.class;
	}

	
	@Override
	public String toString() {
		return "Client [clientId=" + clientId + ", name=" + name + ", lastName=" + lastName + ", dni=" + dni + "]";
	}

	@Override
	public Long getId() {
		return this.clientId;
	}

	@Override
	public void setId(Long id) {
		this.clientId = id;
	}


	
}
