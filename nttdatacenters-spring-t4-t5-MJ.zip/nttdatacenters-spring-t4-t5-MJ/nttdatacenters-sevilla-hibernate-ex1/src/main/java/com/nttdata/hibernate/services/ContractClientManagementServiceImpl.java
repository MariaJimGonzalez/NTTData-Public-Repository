package com.nttdata.hibernate.services;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;

import com.nttdata.hibernate.persistence.Client;
import com.nttdata.hibernate.persistence.ContractClient;
import com.nttdata.hibernate.persistence.ContractClientDaoI;
import com.nttdata.hibernate.persistence.ContractClientDaoImpl;

public class ContractClientManagementServiceImpl implements ContractClientManagementServiceI {

	/** DAO: NTTDATA_HEX_CONTRACT */
	private ContractClientDaoI contractClientDaoI;

	/**
	 * Método constructor.
	 */
	public ContractClientManagementServiceImpl(final Session session) {
		this.contractClientDaoI = new ContractClientDaoImpl(session);
	}

	@Override
	public void insertNewContract(final ContractClient newContract) {

		// Verificación de nulidad e inexistencia.
		if (newContract != null && newContract.getContractId() == null) {

			// Insercción del nuevo contrato.
			contractClientDaoI.insert(newContract);
		}

	}

	@Override
	public void updateContract(final ContractClient updatedContract) {

		// Verificación de nulidad y existencia.
		if (updatedContract != null && updatedContract.getContractId() != null) {

			// Actualización del contrato.
			contractClientDaoI.update(updatedContract);
		}

	}

	@Override
	public void deleteContract(final ContractClient deletedContract) {

		// Verificación de nulidad y existencia.
		if (deletedContract != null && deletedContract.getContractId() != null) {

			// Eliminación del contrato.
			contractClientDaoI.delete(deletedContract);
		}

	}

	@Override
	public ContractClient searchById(final Long contractId) {

		// Resultado.
		ContractClient contractClient = null;

		// Verificación de nulidad.
		if (contractId != null) {

			// Obtención del contrato por ID.
			contractClient = contractClientDaoI.searchById(contractId);
		}

		return contractClient;
	}

	@Override
	public List<Client> searchAll() {

		// Resultado.
		List<Client> contractsList = new ArrayList<>();

		// Obtención de contratos.
		contractsList = contractClientDaoI.searchAll();

		return contractsList;
	}

}
