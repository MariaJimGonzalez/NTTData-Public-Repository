package com.nttdata.hibernate.services;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nttdata.hibernate.persistence.Client;
import com.nttdata.hibernate.persistence.ClientDaoI;
import com.nttdata.hibernate.persistence.ClientDaoImpl;
import com.nttdata.hibernate.repository.ClientRepository;

@Service
public class ClientManagementServiceImpl implements ClientManagementServiceI {
	
//	@Autowired
	private ClientRepository clientRepository;
	
	final Logger log = Logger.getLogger("com.nttdata.hibernate.services.ClientManagementServiceImpl");
	
	
	private ClientDaoI clientDao;

	/**
	 * Método constructor.
	 */
//	public ClientManagementServiceImpl(final Session session) {
//		this.clientDao = new ClientDaoImpl(session);
//	}

	@Override
	public void insertNewClient(final Client newClient) {

		// Verificación de nulidad e inexistencia.
		if (newClient != null && newClient.getClientId() == null) {

			// Insercción del nuevo cliente
			clientDao.insert(newClient);
		}

	}

	@Override
	public void updateClient(final Client updatedClient) {

		// Verificación de nulidad y existencia.
		if (updatedClient != null && updatedClient.getClientId() != null) {

			// Actualización del cliente
			clientDao.update(updatedClient);
		}

	}

	@Override
	public void deleteClient(final Client deletedClient) {

		// Verificación de nulidad y existencia.
		if (deletedClient != null && deletedClient.getClientId() != null) {

			// Eliminación del cliente
			clientDao.delete(deletedClient);
		}

	}

	@Override
	public Client searchById(final Long clientId) {

		// Resultado.
		Client client = null;

		// Verificación de nulidad.
		if (clientId != null) {

			// Obtención del jugador por ID.
			client = (Client) clientDao.searchById(clientId);
		}

		return client;
	}
	
	
	@Override
	public List<Client> searchByNameAndLastName(final String name, final String lastName) {

		// Resultado.
		List<Client> clientList = new ArrayList<>();

		// Verificación de nulidad.
		if ((StringUtils.isNotBlank(name) && StringUtils.isNotBlank(lastName))) {

			// Obtención del cliente por nombre y apellido.
			clientList = clientDao.searchByNameAndLastName(name,lastName);

		}

		return clientList;
	}
	
	@Override
	public List<Client> searchAll() {

		// Resultado.
		List<Client> clientList = new ArrayList<>();

		// Obtención de clientes
		clientList = clientDao.searchAll();

		return clientList;
	}

	@Override
	public List<Client> searchByNameLastname(String name, String lastname) {
		return clientRepository.findByNameAndLastname(name, lastname);
	}


}
