package com.nttdata.hibernate.persistence;

import java.util.List;
import java.util.logging.Logger;

import org.hibernate.Session;

public class ClientDaoImpl extends CommonDaoImpl<Client> implements ClientDaoI {

	final Logger log = Logger.getLogger("com.nttdata.hibernate.persistence.ClientDaoImpl");

	public ClientDaoImpl(Session session) {
		super(session);
		this.session = session;
	}

	public Client searchById(final Long id) {
		// Verificación de sesión abierta.
		if (!session.getTransaction().isActive()) {
			session.getTransaction().begin();
		}

		return (Client) session.createQuery("FROM clientes_table WHERE id=" + id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Client> searchByNameAndLastName(final String name, final String lastName) {

		// Verificación de sesión abierta.
		if (!session.getTransaction().isActive()) {
			session.getTransaction().begin();
		}

		// Localiza jugadores en función del nombre.
		return session.createQuery("FROM clientes_table WHERE name=" + name + "and last_name = " + lastName).list();

	}

}
