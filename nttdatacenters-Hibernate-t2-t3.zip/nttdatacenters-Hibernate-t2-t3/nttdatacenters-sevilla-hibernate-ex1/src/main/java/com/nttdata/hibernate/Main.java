package com.nttdata.hibernate;

import java.util.Date;
import java.util.logging.Logger;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;

import com.nttdata.hibernate.persistence.Client;
import com.nttdata.hibernate.persistence.ContractClient;
import com.nttdata.hibernate.services.ClientManagementServiceI;
import com.nttdata.hibernate.services.ClientManagementServiceImpl;
import com.nttdata.hibernate.services.ContractClientManagementServiceI;
import com.nttdata.hibernate.services.ContractClientManagementServiceImpl;


public class Main {
	
	@Autowired
	private static ClientManagementServiceI clientManagementServiceI;
	
	/**
	 * Método principal
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		final Logger log = Logger.getLogger("com.nttdata.hibernate.NTTDataMain");

		// Apertura de sesión.
		final Session session = NTTDataHibernateUtil.getSessionFactory().openSession();

		// Inicialización de servicios.
		final ClientManagementServiceI clientService = new ClientManagementServiceImpl();
		final ContractClientManagementServiceI contractClientService = new ContractClientManagementServiceImpl(session);

		// Auditoría.
		final String updatedUser = "NTTSPORT_SYS";
		final Date updatedDate = new Date();

		// Generación de jugadores.
		final Client client1 = new Client();
		client1.setName("Artsiom");
		client1.setLastName("Krautsou");
		client1.setDni("06534334D");
		client1.setUpdatedDate(updatedDate);
		client1.setUpdatedUser(updatedUser);
		
		final Client client2 = new Client();
		client2.setName("Manuel");
		client2.setLastName("Fernández");
		client2.setDni("65434234B");
		client2.setUpdatedDate(updatedDate);
		client2.setUpdatedUser(updatedUser);

		// Generación de contratos.
		final ContractClient contract1 = new ContractClient();
		contract1.setSalary("1");
		contract1.setUpdatedDate(updatedDate);
		contract1.setUpdatedUser(updatedUser);
		final ContractClient contract2 = new ContractClient();
		contract2.setSalary("2");
		contract2.setUpdatedDate(updatedDate);
		contract2.setUpdatedUser(updatedUser);


		clientService.insertNewClient(client1);
		clientService.insertNewClient(client2);

		contractClientService.insertNewContract(contract1);
		contractClientService.insertNewContract(contract2);

		
	}

}
