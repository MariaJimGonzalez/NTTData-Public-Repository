package com.nttdata.hibernate.services;

import java.util.List;

import com.nttdata.hibernate.persistence.Client;

public interface ClientManagementServiceI {

	/**
	 * Inserts a new client
	 * 
	 * @param newClient
	 */
	public void insertNewClient(final Client client);
	/**
	 * updates a client
	 * 
	 * @param updatedClient
	 */
	public void updateClient(final Client updatedClient);

	/**
	 * delete a client
	 * 
	 * @param deletedClient
	 */
	public void deleteClient(final Client deletedClient);

	/**
	 * get a client by its id
	 * 
	 * @param ClientId
	 */
	public Client searchById(final Long clientId);

	/**
	 * get a client by its absolutely name
	 * 
	 * @param name
	 * @return List<Client>
	 */
	public List<Client> searchByNameAndLastName(final String name,final String lastName);

	/**
	 * get all the existing clients
	 * 
	 * @return List<Client>
	 */
	public List<Client> searchAll();
	
	public List<Client> searchByNameLastname(String anme, String lastname);

	
}
