package com.nttdata.hibernate.persistence;


public interface ContractClientDaoI extends CommonDaoI<ContractClient> {

}
