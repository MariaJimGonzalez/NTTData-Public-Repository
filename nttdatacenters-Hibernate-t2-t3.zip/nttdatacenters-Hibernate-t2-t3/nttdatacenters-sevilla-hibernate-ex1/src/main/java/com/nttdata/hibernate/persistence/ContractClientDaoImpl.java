package com.nttdata.hibernate.persistence;

import org.hibernate.Session;

public class ContractClientDaoImpl extends CommonDaoImpl<ContractClient> implements ContractClientDaoI {

	/** Sesión de conexión a BD */
	private Session session;

	/**
	 * Método constructor
	 */
	public ContractClientDaoImpl(Session session) {
		super(session);
		this.session = session;
	}

}
