package com.nttdata.tomcat;
 /**
  * Primer JSP
  * @author María Jiménez
  *
  */
public class NTTDATAJSP {
	/**
	 * Constructor por defecto
	 */
	public NTTDATAJSP() {
		
	}

	public static String helloNTTDATADUAL(final String msg) {
		return "Dual 2022" + msg;
	}
}
