package com.spring.repository;

public class Producto {
	
	/** ID del producto */
	private Long productoId;

	/** Nombre del producto */
	private String nombreProducto;

	/** Precio PVP */
	private Double pvp;
	
	/** Precio sin impuestos */
	private Double precioSinImpuestos;	

	public Long getProductoId() {
		return productoId;
	}

	public void setProductoId(Long productoId) {
		this.productoId = productoId;
	}

	public String getNombreProducto() {
		return nombreProducto;
	}

	public void setNombreProducto(String nombreProducto) {
		this.nombreProducto = nombreProducto;
	}

	public Double getPvp() {
		return pvp;
	}

	public void setPvp(Double pvp) {
		this.pvp = pvp;
	}

	public Double getPrecioSinImpuestos() {
		return precioSinImpuestos;
	}

	public void setPrecioSinImpuestos(Double precioSinImpuestos) {
		this.precioSinImpuestos = precioSinImpuestos;
	}

}
