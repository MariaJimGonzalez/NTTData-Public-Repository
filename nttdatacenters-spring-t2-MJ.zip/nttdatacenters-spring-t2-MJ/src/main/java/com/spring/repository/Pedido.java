package com.spring.repository;

import java.util.List;

import javax.persistence.OneToMany;

import org.springframework.beans.factory.annotation.Autowired;

public class Pedido {
	
	/** ID del pedido */
	private Long pedidoId;

	/** Nombre del destinatario */
	private String nombreDestinatario;

	/** Nombre del destinatario */
	private Long ciudadesId;
	
	/** Lista de productos */
	private List <Producto> listaProductos;
	
	
	
	@Autowired
	public Pedido(Long pedidoId, String nombreDestinatario, Long ciudadesId, List<Producto> listaProductos) {
		super();
		this.pedidoId = pedidoId;
		this.nombreDestinatario = nombreDestinatario;
		this.ciudadesId = ciudadesId;
		this.listaProductos = listaProductos;
	}

	public Long getPedidoId() {
		return pedidoId;
	}

	public void setPedidoId(Long pedidoId) {
		this.pedidoId = pedidoId;
	}

	public String getNombreDestinatario() {
		return nombreDestinatario;
	}

	public void setNombreDestinatario(String nombreDestinatario) {
		this.nombreDestinatario = nombreDestinatario;
	}

	public Long getCiudadesId() {
		return ciudadesId;
	}

	public void setCiudadesId(Long ciudadesId) {
		this.ciudadesId = ciudadesId;
	}
	
	public List<Producto> getListaProductos() {
		return listaProductos;
	}

	public void setListaProductos(List<Producto> listaProductos) {
		this.listaProductos = listaProductos;
	}
	
	
}
