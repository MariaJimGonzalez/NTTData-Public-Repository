package com.spring.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.spring.repository.Pedido;
import com.spring.repository.Producto;

@Service("others")
public class ProductManagerOthersServiceImpl implements ProductManagementServiceI {


	@Override
	public void AddProductToAnOrder(Pedido orden, Producto producto) {
		Double iva = getIva(producto.getPrecioSinImpuestos());
		producto.setPvp(iva + producto.getPrecioSinImpuestos());
		orden.getListaProductos().add(producto);
	}

	@Override
	public Pedido createOrder(Long pedidoId, String nombreDestinatario, Long ciudadesId, List<Producto> listaProductos) {
		return new Pedido(pedidoId, nombreDestinatario, ciudadesId, listaProductos);
	}
	
	private Double getIva(Double precioBase) {
		return (4 * precioBase) / 100;
	}

}
