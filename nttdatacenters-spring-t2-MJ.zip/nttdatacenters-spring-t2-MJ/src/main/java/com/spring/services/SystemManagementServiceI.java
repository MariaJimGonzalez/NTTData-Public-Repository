package com.spring.services;

public interface SystemManagementServiceI {

	/**
	 * Comprueba el gasto mensual.
	 * 
	 * @param month
	 */
	public void checkMonthlyExpenditure(final String month);

}
