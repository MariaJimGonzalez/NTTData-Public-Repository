package com.spring.services;

import java.util.List;

import com.spring.repository.Pedido;
import com.spring.repository.Producto;

public interface ProductManagementServiceI {

	public Pedido createOrder(Long pedidoId, String nombreDestinatario, Long ciudadesId,
			List<Producto> listaProductos);
	
	public void AddProductToAnOrder(Pedido orden, Producto producto);
	
}



