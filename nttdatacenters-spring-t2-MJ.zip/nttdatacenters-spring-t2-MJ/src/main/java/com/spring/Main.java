package com.spring;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Lazy;

import com.spring.repository.Pedido;
import com.spring.repository.Producto;
import com.spring.services.ProductManagementServiceI;
import com.spring.services.SystemManagementServiceI;

@SpringBootApplication()
public class Main implements CommandLineRunner {

	/** Servicio: sistema */
	@Autowired
	private SystemManagementServiceI systemService;

	
	@Autowired
	private ProductManagementServiceI productManagerPeninsula;

	@Autowired
	@Qualifier("others")
	private ProductManagementServiceI productManagerOthers;
	
	public static void main(String[] args) {
		SpringApplication.run(Main.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		final String month = "12";
		
		//Creación del producto y seteo de los atributos
		Producto p = new Producto();
		Double noImpuestos = (double) 4.6;
		Double pvp = (double) 1.6;
		Long id = (long) 5467;
		p.setNombreProducto("Orden03");
		p.setPrecioSinImpuestos(noImpuestos);
		p.setProductoId(id);
		p.setPvp(pvp);
		
		//Creación de la lista de producto
		List<Producto> lista = new ArrayList<Producto>();
		lista.add(p);
		
		//Creación del pedido
		
		Long pedidoId = (long) 456;
		Long ciudadId = (long) 43;
		String nombreDestinatario = "Paco";
		
		Pedido pe = new Pedido(pedidoId, nombreDestinatario, ciudadId, lista);
		pe.setPedidoId(id);
		
	
		
		productManagerPeninsula.createOrder(pedidoId, nombreDestinatario, ciudadId, lista);
		productManagerPeninsula.AddProductToAnOrder(pe, p);
		productManagerOthers.createOrder(pedidoId, nombreDestinatario, ciudadId, lista);
		productManagerOthers.AddProductToAnOrder(pe, p);
		
	}

}
