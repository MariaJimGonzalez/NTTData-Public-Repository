package com.everis.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EverisSpringMvcTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
