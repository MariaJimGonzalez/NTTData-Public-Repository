package com.nttdata.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Queries {
	
	public static void BDDQueries() throws ClassNotFoundException, SQLException {
		
		Connection dbConnection = DBBConnection.stablishConection();
	try {
			// Realización de consulta.
			final Statement sentence = dbConnection.createStatement();
			final String query = "select sp.Name as firstName, st.name as teamName, st.first_color as firstColor, st.second_color as secondColor FROM nttdata_mysql_soccer_player sp JOIN nttdata_mysql_soccer_team st ON sp.id_soccer_team = st.id_soccer_team where sp.Name like 'J%' order by sp.Name;";
			final ResultSet queryResult = sentence.executeQuery(query);

			// Iteración de resultados.
			StringBuilder playerInfo = new StringBuilder();
			while (queryResult.next()) {

				playerInfo.append("Nombre: ");
				playerInfo.append(queryResult.getString("firstName"));
				
				playerInfo.append(" | Nombre equipo: ");
				playerInfo.append(queryResult.getString("teamName"));

				playerInfo.append(" | First color: ");
				playerInfo.append(queryResult.getString("firstColor"));

				playerInfo.append(" | Second color: ");
				playerInfo.append(queryResult.getString("secondColor"));

				playerInfo.append("\n");
			}

			System.out.println(playerInfo.toString());

			// Cierre de conexión con BBDD.
			dbConnection.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	}


