package com.nttdata.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBBConnection {
	public static Connection stablishConection() throws ClassNotFoundException, SQLException {
		
		// Se establece el driver de conexión a BBDD.
		Class.forName("com.mysql.cj.jdbc.Driver");

		// Apertura de conexión con BBDD (URL / Usuario / Contraseña)
		final Connection dbConnection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/nttdata_jdbc_ex", "root", "toorDam2");
	
	return dbConnection;

}
}
