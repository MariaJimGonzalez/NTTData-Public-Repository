package com.nttdata.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class NTTDataMain {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		// Conexión y ejecución de consulta a BD (MySQL).
		Queries.BDDQueries();
	}



}
